public class arithmeticOperatorsABK {
    public static void main(String[] args) {
    // The code snippet is performing arithmetic operations on two floating-point numbers `num1` and`num2`. 
        float num1 = 10.5f, num2 = 5.2f;

        System.out.println("Sum :" + (num1 + num2));
        System.out.println("Difference :" + (num1 - num2));
        System.out.println("Multiplication :" + (num1 * num2));
        System.out.println("Division :" + (num1 / num2));
    }
}